# Thanks for Code Contributing
* [Christopher Newton](https://github.com/chrstphrknwtn)

# Thanks for Support
* Stephen Lebed

* jonas grigonis
* nildo essa
* gary jay smith

* thorn@neverwake.com

# Thanks for Donate
* Pamela Okoro
* bikekefeli@gmail.com
* d_phantom70@hotmail.com
* kuroiluna@hotmail.com
* solenekinkielele@yahoo.fr

* revovl@gmail.com
* shane@studiopiper.com.au
* tmdals1825@gmail.com

# Note
* Unfortunately, I don't have all the names. If you're reading this, please send me your name and webpage if you'd like to be added to the list.
