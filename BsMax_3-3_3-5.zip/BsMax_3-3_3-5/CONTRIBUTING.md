# Licence
* licence text most be on top of all files.
* 

# Import
* 

# Public bsmax library
* 

# Variables
* variable name start with lower case and camel cap.
* much as possble do not try to short the names.
* e.g. good sample "theObjectName"
* e.g. bas sample "tObjNm"
* Do not use global variable much as possible and use it only inside a single py file.
* Define global variables up side of the code right after the imports.

# Function
* Function names all lower case and seprate with '_'.
* e.g. "get_data_from()"
* Define all function befor classes
* if a function exclusive for a class start function name with full class name

# Classes
* Class name start with upper case and camel cap.
* e.g. "MasterClassName"
* Define classes at the last of code right befor register functions.
* Try to do not right much code inside the classes define variables and function and then link function to an external function. this makes code mode readable and easy to understand.

# Operator Classes
* 

# Menu

# Register
* register and unregister functions came on end of each python file.
* this functions names satart with register or unregister and then file name.
* if prefrence data need in file sent it thruh register fanction from main _init_ file.
* e.g. register_animation(prefrence)

# Tets
* 