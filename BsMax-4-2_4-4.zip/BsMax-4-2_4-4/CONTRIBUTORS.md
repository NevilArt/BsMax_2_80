# Thanks for Code Contributing
* [Christopher Newton](https://github.com/chrstphrknwtn)

# Thanks for Donate and Support
* Stephen Lebed

* jonas grigonis
* nildo essa
* gary jay smith
* Sviatoslav Voskreenskyi

* thorn@neverwake.com
* fahranyounas@googlemail.com

* Pamela Okoro
* Libor D.
* david goldstein
* bikekefeli@gmail.com
* d_phantom70@hotmail.com
* kuroiluna@hotmail.com
* solenekinkielele@yahoo.fr
* youngjaekim
* m.w.clapperton@gmail.com

* Nattapong Khwanpray
* Florian Schreiber
* Ibra SOW
* Filip Streck
* revovl@gmail.com
* shane@studiopiper.com.au
* tmdals1825@gmail.com
* ddr3653@gmail.com
* richierr@gmail.com
* jackpot0006@yahoo.com
* zeusjustine@gmail.com
